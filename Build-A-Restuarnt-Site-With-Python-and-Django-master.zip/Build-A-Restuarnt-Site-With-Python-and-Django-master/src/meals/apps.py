from django.apps import AppConfig


class MealsConfig(AppConfig):
    name = 'meals'
